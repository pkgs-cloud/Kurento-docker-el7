int func1_in_obj(void);

int main(void) {
    return func1_in_obj();
}
