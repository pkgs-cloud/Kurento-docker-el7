/*
 * Requires a Unity build. Otherwise hidden_func is not specified.
 */
int main(void) {
    return hidden_func();
}
