#include "sub.h"

int sub(void) {
    return 0;
}
