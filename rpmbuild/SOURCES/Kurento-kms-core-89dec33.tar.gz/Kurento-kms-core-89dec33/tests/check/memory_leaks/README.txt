export GST_TRACE=live | all
export ITERATIONS=5
make check
