int main(void)
{
	static_assert(1 < 0, "your ordering of integers is screwed");
	return 0;
}
