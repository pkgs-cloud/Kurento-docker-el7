#if !defined(_MSC_VER)
#include <signal.h>
#include <features.h>
#endif
int main(int argc, char *argv[]) { return 0; }
