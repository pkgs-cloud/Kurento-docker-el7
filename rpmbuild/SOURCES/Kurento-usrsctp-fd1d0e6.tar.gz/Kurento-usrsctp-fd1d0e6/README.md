# usrsctp

This is a userland SCTP stack supporting FreeBSD, Linux, Mac OS X and Windows.

See [manual](Manual.md) for more information.

The status of continous integration testing is available from [grid](http://212.201.121.77:18010/grid) and [waterfall](http://212.201.121.77:18010/waterfall).
