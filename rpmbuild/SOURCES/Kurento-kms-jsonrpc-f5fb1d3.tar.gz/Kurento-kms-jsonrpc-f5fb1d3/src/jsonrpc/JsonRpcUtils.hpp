/*
 * (C) Copyright 2014 Kurento (http://kurento.org/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef __JSONRPC_UTILS_HPP__
#define __JSONRPC_UTILS_HPP__

#include <json/json.h>

namespace kurento
{
namespace JsonRpc
{

void getValue (const Json::Value &params, const std::string &name,
               std::string &_return);

void getValue (const Json::Value &params, const std::string &name,
               int &_return);

void getValue (const Json::Value &params, const std::string &name,
               bool &_return);

void getValue (const Json::Value &params, const std::string &name,
               Json::Value &_return);

void getArray (const Json::Value &params, const std::string &name,
               Json::Value &_return);

} /* JsonRpc */
} /* kurento */

#endif /* __JSONRPC_UTILS_HPP__ */
