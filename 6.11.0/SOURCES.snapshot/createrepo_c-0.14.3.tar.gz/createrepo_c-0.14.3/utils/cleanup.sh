#!/bin/bash

rm -fv createrepo_c-*.tar.xz
rm -fv createrepo_c-*.rpm python-createrepo_c-*.rpm python3-createrepo_c-*.rpm
rm -fv deltarepo-*.rpm python-deltarepo-*.rpm
