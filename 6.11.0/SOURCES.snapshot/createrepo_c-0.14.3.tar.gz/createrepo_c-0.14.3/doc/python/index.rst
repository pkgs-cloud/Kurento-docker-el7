############
createrepo_c
############

A library providing C and Python API for reading headers of
rpm packages and reading and writing yum repository metadata.

Contents:

.. toctree::
   :maxdepth: 2
   
   lib

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

