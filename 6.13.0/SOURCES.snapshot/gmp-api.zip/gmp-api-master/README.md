This repository contains the headers for developing Gecko Media Plugins. Gecko syncs with this repository.
